%计算402个供货商的供货能力

function E=getE(order,supply)
global rows cols
E=zeros(rows,1);

%只考虑供货量/订货量>=0.9的供货数据，找到这些数据的平均值就是该供货商的供货能力
rate=zeros(rows,cols);
for i=1:rows
    for j=1:cols
        if order(i,j)==0
            rate(i,j)=0;
            continue;
        end
        rate(i,j)=supply(i,j)/order(i,j);
    end
end
for i=1:rows
    fd=find(rate(i,:)>=0.9);
    tmp=[];
    for j=1:length(fd)
        tmp=[tmp,supply(i,fd(j))];
    end
    if isempty(tmp)
        continue;
    end
    E(i)=mean(tmp);
end
end