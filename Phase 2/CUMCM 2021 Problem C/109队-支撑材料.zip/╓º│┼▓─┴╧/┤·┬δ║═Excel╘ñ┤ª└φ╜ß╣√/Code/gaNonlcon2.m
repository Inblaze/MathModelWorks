function [c,ceq]=gaNonlcon2(x)
global E leastChoices headA headB headC tailA tailB tailC s lastRest2
SA=find(headA<=leastChoices&leastChoices<=tailA);
SB=find(headB<=leastChoices&leastChoices<=tailB);
SC=find(headC<=leastChoices&leastChoices<=tailC);
c(1)=x(190)-lastRest2(1);
for i=1:length(SA)
    for j=1:8
        c(1)=c(1)-E(leastChoices(SA(i)))*x(SA(i))*x(22+(j-1)*21+SA(i)-1)*(1-s(j));
    end
end
c(2)=x(191)-lastRest2(2);
for i=1:length(SB)
    for j=1:8
        c(2)=c(2)-E(leastChoices(SB(i)))*x(SB(i))*x(22+(j-1)*21+SB(i)-1)*(1-s(j));
    end
end
c(3)=x(192)-lastRest2(3);
for i=1:length(SC)
    for j=1:8
        c(3)=c(3)-E(leastChoices(SC(i)))*x(SC(i))*x(22+(j-1)*21+SC(i)-1)*(1-s(j));
    end
end
c(4)=2*28200+x(190)/0.6+x(191)/0.66+x(192)/0.72-lastRest2(1)/0.6-lastRest2(2)/0.66-lastRest2(3)/0.72;
for i=1:length(SA)
    for j=1:8
        c(4)=c(4)-(E(leastChoices(SA(i)))*x(SA(i))*x(22+(j-1)*21+SA(i)-1)*(1-s(j)))/0.6;
    end
end
for i=1:length(SB)
    for j=1:8
        c(4)=c(4)-(E(leastChoices(SB(i)))*x(SB(i))*x(22+(j-1)*21+SB(i)-1)*(1-s(j)))/0.66;
    end
end
for i=1:length(SC)
    for j=1:8
        c(4)=c(4)-(E(leastChoices(SC(i)))*x(SC(i))*x(22+(j-1)*21+SC(i)-1)*(1-s(j)))/0.72;
    end
end
for j=1:8
    c(4+j)=-6000;
    for i=1:length(leastChoices)
        c(4+j)=c(4+j)+E(leastChoices(i))*x(i)*x(22+(j-1)*21+i-1);
    end
end
ceq=[];
end