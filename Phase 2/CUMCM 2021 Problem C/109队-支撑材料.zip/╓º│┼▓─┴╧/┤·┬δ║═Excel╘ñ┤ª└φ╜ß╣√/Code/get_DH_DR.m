%求诚信度和依赖度

function [DH,DR]=get_DH_DR(order,supply)
global headA tailA headB tailB headC tailC rows cols
offset=zeros(rows,cols);
for i=1:rows
    for j=1:cols
        if order(i,j)==0
            continue;
        end
        offset(i,j)=abs(supply(i,j)-order(i,j))/order(i,j);
    end
end

%topsis计算诚信度

%正理想解为全0的行向量
PIS=zeros(1,cols);
%负理想解所有元素为整个矩阵中的最大值的行向量
NIS=zeros(1,cols);
NIS(1,:)=max(offset,[],'all');
%经过验证负理想解就是全1的行向量

%计算各个供货商的综合评价值

%计算各个被评价对象到PIS的欧氏距离
dPIS=zeros(rows,1);
for i=1:rows
    dPIS(i,1)=sqrt(sum((offset(i,:)-PIS(1,:)).^2));
end

%计算各个被评价对象到NIS的欧氏距离
dNIS=zeros(rows,1);
for i=1:rows
    dNIS(i,1)=sqrt(sum((offset(i,:)-NIS(1,:)).^2));
end

%计算各评价对象的综合评价值(诚信度)
DH=zeros(rows,1);
DH=dNIS./(dPIS+dNIS);

%计算依赖度

sumOrder=sum(order,2); %计算每个供货商的总订购量
sumOrderInType=zeros(3,1); %A,B,C三种材料的总订购量，sumOrderInType(1)表示A的总订购量
sumOrderInType(1)=sum(sumOrder(headA:tailA));
sumOrderInType(2)=sum(sumOrder(headB:tailB));
sumOrderInType(3)=sum(sumOrder(headC:tailC));

%计算向该供应商订购的货物数在该类型中的总订购货物中的占比
R=zeros(rows,1);
R(headA:tailA)=sumOrder(headA:tailA)/sumOrderInType(1);
R(headB:tailB)=sumOrder(headB:tailB)/sumOrderInType(2);
R(headC:tailC)=sumOrder(headC:tailC)/sumOrderInType(3);

%得到依赖度DR
maxR=max(R);
DR=R/maxR; %依赖度
end