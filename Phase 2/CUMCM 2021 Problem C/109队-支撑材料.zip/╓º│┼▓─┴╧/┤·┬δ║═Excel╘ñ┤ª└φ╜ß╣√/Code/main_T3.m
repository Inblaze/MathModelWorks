clc,clear

%Qestion 1

%导入根据类型排序后的订购量和供货量
load 根据类型排序后的订购量和供货量及对应的供货商id.mat
global headA tailA headB tailB headC tailC rows cols E leastChoices CA CB CC s lastRest1
%syms CA CB CC
CA=1.2; CB=1.1; CC=1;
[rows cols]=size(order);
headA=1;tailA=146;   %1到146行为A材料供货商
headB=147;tailB=280; %147到280为B材料供货商
headC=281;tailC=402; %281到402为C材料供货商
SA=find(headA<=leastChoices&leastChoices<=tailA);
SB=find(headB<=leastChoices&leastChoices<=tailB);
SC=find(headC<=leastChoices&leastChoices<=tailC);


%求诚信度和依赖度
[DH,DR]=get_DH_DR(order,supply);
%求诚信度和依赖度的权重
[WH,WR]=get_WH_WR(DH,DR);
%score为他们的综合评分
score=WH*DH+WR*DR;
%找出前50名在列向量中的下标,存储在goodTrader的第一列
goodTrader=zeros(50,2);
goodTrader(:,1)=getGoodTrader(score);

%Question 2

%获得402个供货商的供货能力（平均供货量）向量
E=getE(order,supply); %得到每个供货商平均供货量
cE=zeros(402,1); %cE为将元素数值转换为对应能生产的产品数后的向量
cE(headA:tailA)=E(headA:tailA)/0.6;
cE(headB:tailB)=E(headB:tailB)/0.66;
cE(headC:tailC)=E(headC:tailC)/0.72;

%前50名供货商的平均供货量对应能生产的产品数存储在goodTrader第二列
for i=1:50
    goodTrader(i,2)=cE(goodTrader(i,1));
end
sorted_GoodTrader=sortrows(goodTrader,-2);
sorted_GoodTrader(:,3)=zeros(50,1);
sorted_GoodTrader(1,3)=sorted_GoodTrader(1,2);
%求前缀和（包括该元素）
for i=2:50
    sorted_GoodTrader(i,3)=sorted_GoodTrader(i-1,3)+sorted_GoodTrader(i,2);
end

%最少选择的供货商
leastChoices=sorted_GoodTrader(find(sorted_GoodTrader(:,3)<=28200),1);
leastChoices=[leastChoices;sorted_GoodTrader(length(leastChoices)+1,1)];
id_leastChoices=id(leastChoices);
fprintf('最少选择%d家供应商，他们的编号如下:\n',length(leastChoices))
disp(id_leastChoices')

%最经济订购方案求解

%还要算出当周rest
s=[1.904769167,0.921370417,0.186055556,1.570482353,2.889825301,0.543761111,2.078833333,1.010282759]/100;
nowRest1=zeros(25,3);
x1=zeros(24,21);
y1=zeros(21,8,24);
use1=zeros(24,3);
fval1=zeros(24,1);
nowRest1(1,:)=[28200*0.6*2/3,28200*0.66*2/3,28200*0.72*2/3];
lastRest1=zeros(1,3);
% fg1=figure();
% set(fg1,'position',get(0,'ScreenSize'));
totLoss=zeros(24,1);
for i=1:24
    %[x1(i,:),y1(:,:,i),use1(i,:),leastCostFval(i),nowRest1(i+1,:)]=leastCostProg(nowRest1(i,:),s);
    lastRest1=nowRest1(i,:);
    [x1(i,:),y1(:,:,i),gax1,gafval1,use1(i,:),nowRest1(i+1,:)]=gaProg_T3();
    totLoss(i)=0;
    for ii=1:length(SA)
        for j=1:8
            totLoss(i)=totLoss(i)+E(leastChoices(SA(ii)))*x1(SA(ii))*CA*s(j)*y1(SA(ii),j);
        end
    end
    for ii=1:length(SB)
        for j=1:8
            totLoss(i)=totLoss(i)+E(leastChoices(SB(ii)))*x1(SB(ii))*CB*s(j)*y1(SB(ii),j);
        end
    end
    for ii=1:length(SC)
        for j=1:8
            totLoss(i)=totLoss(i)+E(leastChoices(SC(ii)))*x1(SC(ii))*CC*s(j)*y1(SC(ii),j);
        end
    end
    fval1(i,1)=gafval1(1,:);
end

orderx=zeros(402,24); %订购方案
transy=zeros(402,8,24); %转运方案
for i=1:24
    orderx(id_leastChoices(find(x1(i,:)==1)),i)=E(leastChoices((find(x1(i,:)==1))));
end
tmp=[E(leastChoices),E(leastChoices),E(leastChoices),E(leastChoices),E(leastChoices),E(leastChoices),E(leastChoices),E(leastChoices)];
for i=1:24
    transy(id_leastChoices,:,i)=y1(:,:,i).*tmp;
end


