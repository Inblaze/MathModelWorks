function [x1,M,gax1,gafval1,use1,nowRest1]=gaProg_T4()
%tx(1)~tx(402)是x矩阵
%tx(403)~tx(405)是useA,useB,useC
%tx(406)是M
global E headA headB headC tailA tailB tailC s lastRest1
ns=5;
nvar=406;
A=zeros(ns,nvar);
B=zeros(ns,1);
A(1,1:402)=E;
B(1)=48000;
A(2,headA:tailA)=-(1-s)*E(headA:tailA);
A(2,403)=1; B(2)=lastRest1(1);
A(3,headB:tailB)=-(1-s)*E(headB:tailB);
A(3,404)=1; B(3)=lastRest1(2);
A(4,headC:tailC)=-(1-s)*E(headC:tailC);
A(4,405)=1; B(4)=lastRest1(3);
A(5,403:406)=[1/0.6,1/0.66,1/0.72,2];
A(5,headA:tailA)=-((1-s)/0.6)*E(headA:tailA);
A(5,headB:tailB)=-((1-s)/0.66)*E(headB:tailB);
A(5,headC:tailC)=-((1-s)/0.72)*E(headC:tailC);
B(5)=lastRest1(1)/0.6+lastRest1(2)/0.66+lastRest1(3)/0.72;
Aeq=zeros(1,406);
Aeq(403:406)=[1/0.6,1/0.66,1/0.72,-1];
Beq=[0];
lb=zeros(nvar,1);
lb(406)=28211;
ub=zeros(nvar,1);
ub(1:402)=ones(402,1);
ub(403:405)=6000*8;
ub(406)=80000*(1-s);
intcon=[1:402];
options=optimoptions('ga');
options.FunctionTolerance=1e-6;
%options.MaxStallGenerations=400;
%Fun=@gaFun_T4;
%[gax1,gafval1]=ga(Fun,nvar,A,B,Aeq,Beq,lb,ub,[],intcon,options);

f=zeros(1,nvar); f(406)=-1;
[gax1,gafval1]=intlinprog(f,intcon,A,B,Aeq,Beq,lb,ub);

% [gax,fval]=gamultiobj(Fun,nvar,A,B,Aeq,Beq,lb,ub,nonlcon,intcon,optimoptions('gamultiobj'));
x1=gax1(1:402)';
use1=gax1(403:405)';
M=gax1(406);
nowRest1=lastRest1;
for i=headA:tailA
    nowRest1(1)=nowRest1(1)+E(i)*x1(i);
end
nowRest1(1)=nowRest1(1)-use1(1);
for i=headB:tailB
    nowRest1(2)=nowRest1(2)+E(i)*x1(i);
end
nowRest1(2)=nowRest1(2)-use1(2);
for i=headC:tailC
    nowRest1(3)=nowRest1(3)+E(i)*x1(i);
end
nowRest1(3)=nowRest1(3)-use1(3);
end