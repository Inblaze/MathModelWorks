function [x1,y1,gax1,gafval1,use1,nowRest1,x2,y2,gax2,gafval2,use2,nowRest2]=gaProg()
%function [x,y,use,fval,nowRest]=gaProg()
%tx(1)~tx(21)是x矩阵
%{
[tx(22)~tx(42);
 tx(43)~tx(63);
 tx(64)~tx(84);
 tx(85)~tx(105);
 tx(106)~tx(126);
 tx(127)~tx(147);
 tx(148)~tx(168);
 tx(169)~tx(189);]
为y矩阵
%}
%tx(190)~tx(192)是useA,useB,useC
global E leastChoices headA headB headC tailA tailB tailC s lastRest1 lastRest2
SA=find(headA<=leastChoices&leastChoices<=tailA);
SB=find(headB<=leastChoices&leastChoices<=tailB);
SC=find(headC<=leastChoices&leastChoices<=tailC);
ns=42;
nvar=192;
A=zeros(ns,nvar);
B=zeros(ns,1);
%每个供货商的转运商唯一
for i=1:21
    A(i,(22+(i-1)):21:(169+(i-1)))=-1;
    B(i)=0;
end

for i=1:21
    A(21+i,(22+(i-1)):21:(169+(i-1)))=1;
    B(21+i)=1;
end
Aeq=zeros(1,192);
Aeq(190:192)=[1/0.6,1/0.66,1/0.72];
Beq=[28200];
lb=zeros(192,1);
ub=ones(192,1);
ub(190:192)=2*28200;
intcon=[1:189];
options=optimoptions('ga');
options.FunctionTolerance=1e-6;
options.MaxStallGenerations=200;
Fun=@gaFun_LeastPay;
nonlcon=@gaNonlcon1;
[gax1,gafval1]=ga(Fun,nvar,A,B,Aeq,Beq,lb,ub,nonlcon,intcon,options);
Fun=@gaFun_LeastLoss;
nonlcon=@gaNonlcon2;
[gax2,gafval2]=ga(Fun,nvar,A,B,Aeq,Beq,lb,ub,nonlcon,intcon,options);

% [gax,fval]=gamultiobj(Fun,nvar,A,B,Aeq,Beq,lb,ub,nonlcon,intcon,optimoptions('gamultiobj'));

x1=gax1(1,1:21)';
y1=[gax1(1,22:42)',gax1(1,43:63)',gax1(1,64:84)',gax1(1,85:105)',gax1(1,106:126)',gax1(1,127:147)',gax1(1,148:168)',gax1(1,169:189)'];
use1=gax1(1,190:192)';
nowRest1=lastRest1;
for i=1:length(SA)
    for j=1:8
        nowRest1(1)=nowRest1(1)+E(leastChoices(SA(i)))*gax1(SA(i))*y1(SA(i),j)*(1-s(j));
    end
end
nowRest1(1)=nowRest1(1)-use1(1);
for i=1:length(SB)
    for j=1:8
        nowRest1(2)=nowRest1(2)+E(leastChoices(SB(i)))*gax1(SB(i))*y1(SB(i),j)*(1-s(j));
    end
end
nowRest1(2)=nowRest1(2)-use1(2);
for i=1:length(SC)
    for j=1:8
        nowRest1(3)=nowRest1(3)+E(leastChoices(SC(i)))*gax1(SC(i))*y1(SC(i),j)*(1-s(j));
    end
end
nowRest1(3)=nowRest1(3)-use1(3);

x2=gax2(1,1:21)';
y2=[gax2(1,22:42)',gax2(1,43:63)',gax2(1,64:84)',gax2(1,85:105)',gax2(1,106:126)',gax2(1,127:147)',gax2(1,148:168)',gax2(1,169:189)'];
use2=gax2(1,190:192)';
nowRest2=lastRest2;
for i=1:length(SA)
    for j=1:8
        nowRest2(1)=nowRest2(1)+E(leastChoices(SA(i)))*gax2(SA(i))*y2(SA(i),j)*(1-s(j));
    end
end
nowRest2(1)=nowRest2(1)-use2(1);
for i=1:length(SB)
    for j=1:8
        nowRest2(2)=nowRest2(2)+E(leastChoices(SB(i)))*gax2(SB(i))*y2(SB(i),j)*(1-s(j));
    end
end
nowRest2(2)=nowRest2(2)-use2(2);
for i=1:length(SC)
    for j=1:8
        nowRest2(3)=nowRest2(3)+E(leastChoices(SC(i)))*gax2(SC(i))*y2(SC(i),j)*(1-s(j));
    end
end
nowRest2(3)=nowRest2(3)-use2(3);
end