%CRITIC法求诚信度和依赖度的权重
function [WH,WR]=get_WH_WR(DH,DR)
SD=std([DH,DR],0); %方差
r=corrcoef([DH,DR]); %相关系数矩阵
W=SD.*(sum(1-r));
W=W./sum(W);
WH=W(1);WR=W(2);
end