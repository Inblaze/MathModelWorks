function goodTrader=getGoodTrader(score)
[val,idx]=sort(score,1,'descend');
goodTrader=idx(1:50);
end