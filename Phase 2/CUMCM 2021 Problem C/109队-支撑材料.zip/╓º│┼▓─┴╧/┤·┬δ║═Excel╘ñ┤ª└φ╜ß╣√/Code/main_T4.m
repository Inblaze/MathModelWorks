clc,clear


%导入根据类型排序后的订购量和供货量
load 根据类型排序后的订购量和供货量及对应的供货商id.mat
global headA tailA headB tailB headC tailC rows cols E leastChoices CA CB CC s lastRest1
%syms CA CB CC
CA=1.2; CB=1.1; CC=1;
[rows cols]=size(order);
headA=1;tailA=146;   %1到146行为A材料供货商
headB=147;tailB=280; %147到280为B材料供货商
headC=281;tailC=402; %281到402为C材料供货商
SA=find(headA<=leastChoices&leastChoices<=tailA);
SB=find(headB<=leastChoices&leastChoices<=tailB);
SC=find(headC<=leastChoices&leastChoices<=tailC);
E=getE(order,supply); %得到每个供货商平均供货量

s=mean([1.904769167,0.921370417,0.186055556,1.570482353,2.889825301,0.543761111,2.078833333,1.010282759])/100;
nowRest1=zeros(25,3);
x1=zeros(24,402);
M=zeros(24,1);
use1=zeros(24,3);
fval1=zeros(24,1);
%nowRest1(1,:)=[50000*0.6*2/3,50000*0.66*2/3,50000*0.72*2/3];
nowRest1(1,:)=[28200*0.6*2/3,28200*0.66*2/3,28200*0.72*2/3];
lastRest1=zeros(1,3);
for i=1:24
    %[x1(i,:),y1(:,:,i),use1(i,:),leastCostFval(i),nowRest1(i+1,:)]=leastCostProg(nowRest1(i,:),s);
    lastRest1=nowRest1(i,:);
    [x1(i,:),M(i),gax1,gafval1,use1(i,:),nowRest1(i+1,:)]=gaProg_T4();
    fval1(i,1)=gafval1(1,:);
end

transy=zeros(402,8); %对应的供货商和转运商的转运矩阵
%rank1~8转运商对应的id
rankTrans=[3,6,2,8,4,1,7,5];
%rank1~8转运商对应的损耗率[0.186055556,0.543761111,0.921370417,1.010282759,1.570482353,1.904769167,2.078833333,2.889825301]
cntTrans=0;
for i=1:402
    while sum(transy(:,rankTrans(cntTrans+1)))+E(i)>6000
        cntTrans=cntTrans+1;
    end
    transy(id(i),rankTrans(cntTrans+1))=E(i);
end

