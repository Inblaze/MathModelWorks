%tx(1)~tx(21)是x矩阵
%{
[tx(22)~tx(42);
 tx(43)~tx(63);
 tx(64)~tx(84);
 tx(85)~tx(105);
 tx(106)~tx(126);
 tx(127)~tx(147);
 tx(148)~tx(168);
 tx(169)~tx(189);]
为y矩阵
%}
%tx(190)~tx(192)是useA,useB,useC

function y=gaFun_LeastPay(tx)
global E leastChoices headA headB headC tailA tailB tailC CA CB CC
SA=find(headA<=leastChoices&leastChoices<=tailA);
SB=find(headB<=leastChoices&leastChoices<=tailB);
SC=find(headC<=leastChoices&leastChoices<=tailC);
y(1)=E(leastChoices(SA(:)))'*tx(SA(:))'*CA+E(leastChoices(SB(:)))'*tx(SB(:))'*CB+E(leastChoices(SC(:)))'*tx(SC(:))'*CC;
% y(2)=0;
% for i=1:length(SA)
%     for j=1:8
%         y(2)=y(2)+E(leastChoices(SA(i)))*tx(SA(i))*CA*s(j)*tx(22+(j-1)*21+SA(i)-1);
%     end
% end
% for i=1:length(SB)
%     for j=1:8
%         y(2)=y(2)+E(leastChoices(SB(i)))*tx(SB(i))*CB*s(j)*tx(22+(j-1)*21+SB(i)-1);
%     end
% end
% for i=1:length(SC)
%     for j=1:8
%         y(2)=y(2)+E(leastChoices(SC(i)))*tx(SC(i))*CC*s(j)*tx(22+(j-1)*21+SC(i)-1);
%     end
% end
end